package com.neusoft.services.impl.EA;

import com.neusoft.services.JdbcServicesSupport;

public class EA02ServicesSupport extends JdbcServicesSupport 
{

}
